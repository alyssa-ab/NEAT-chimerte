"""
An attempt to use HMM to model the sequencing error
"""

states = 3 # beginning, plateau, end

observations = 0