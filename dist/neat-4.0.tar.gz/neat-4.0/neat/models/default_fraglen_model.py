"""
The following model is the default for the fragment length distribution.
"""

default_fragment_mean = 601.0
default_fragment_std = 103.0
default_fragment_max = 1626.0
default_fragment_min = 3.0